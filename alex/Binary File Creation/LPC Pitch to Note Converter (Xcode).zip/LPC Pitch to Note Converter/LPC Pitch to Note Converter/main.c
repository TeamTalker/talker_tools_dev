//
//  main.c
//  LPC Pitch to Note Converter
//
//  Created by alx on 05/03/2018.
//  Copyright © 2018 alx. All rights reserved.
//

#include <stdio.h>
#include <math.h>

double hz = 0;
double note_fract = 0;
int32_t note_axo = 0;

double freq_to_note(float hz) {
    return 5 + 12 * log2(hz / 440);
};

int32_t note_to_axo(double note) {
    int32_t multiplier = 1<<21;
    return (int32_t)(note * multiplier);
}

int main(int argc, const char * argv[]) {
    
    for(int i = 1; i <= 160; i++) {
        // Herz from cycles
        hz = 8000 / i;
        // Hz to fractional MIDI note (-64 to 64 range)
        note_fract = freq_to_note(hz);
        // Axoloti note value
        printf("%i,\n", note_to_axo(note_fract));
    }

    return 0;
}
